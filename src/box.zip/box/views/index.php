<?php /*
  'id' => $this->id ?? uniqid(),
  'text' => $this->text,
  'name' => $this->name,
  'is_deleted' => $this->is_deleted,
  'is_collapsed' => $this->is_collapsed,
  'is_solid' => $this->is_solid,
  'info' => $this->info,
  'url' => $this->url,
  'fotter' => $this->fotter,
  'type' => $this->type,
 */ ?>

<div id="<?= $id ?>" class="box <?= $is_solid ? "box-solid " : '' ?> box-info <?= !$is_open ? "collapsed-box" : '' ?>">
    <div class="box-header with-border">
        <h3 class="box-title"><?= $name ?></h3>
        <div class="box-tools pull-right"> 
            <?php if (!empty($btn)): ?>
                <?php foreach ($btn as $bt): ?>
                    <?= $bt ?>
                <?php endforeach; ?>
            <?php endif; ?>
            <?php if ($is_collapsed): ?>
                <button onclick="colloapsedBox('<?= $id ?>')" type="button" class="btn btn-box-tool" data-widget="collapse">
                    <i class="fa fa-minus indic-<?= $id ?>">

                    </i>
                </button>
            <?php endif; ?>
            <?php if ($subMenu): ?>   
                <div class = "btn-group">
                    <button type = "button" class = "btn btn-box-tool dropdown-toggle" data-toggle = "dropdown" aria-expanded = "false"><i class = "fa fa-wrench"></i></button>
                    <?=
                    \yii\widgets\Menu::widget([
                        'options' => ['class' => 'dropdown-menu'],
                        'items' => $subMenu
//                             ['label' => 'About', 'url' => ['site/about']],
                    ]);
                    ?>
                </div>
            <?php endif; ?>
            <?php if ($info): ?>
                <span data-toggle="tooltip"  data-placement="left" title="" class="btn btn-box-tool"
                      data-original-title="<?= $info ?>"><i class="fas fa-question"></i>    
                </span>         
            <?php endif; ?>
            <?php if ($is_deleted): ?>
                <button type = "button" class = "btn btn-box-tool" data-widget = "remove"><i class = "fa fa-times"></i></button>
            <?php endif; ?>

        </div>

    </div>
    <div class = "box-body <?= $padding ? "" : ' no-padding' ?>" style = "">
        <?= $text ?>
    </div>
    <!-- /.box-body -->
</div>