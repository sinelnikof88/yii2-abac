<?php

/*
 * Gonnyh Ivan
 * sinelnikof88@gmail.com
 * Developing  by Yii
 * Each line should be prefixed with  * 
 */

namespace common\extensions\box;

class Box extends \yii\base\Widget {

    const sessName = 'sessBox3';

    public $id;
    public $text;
    public $name;
    public $is_deleted;
    public $is_collapsed;
    public $is_solid = true;
    public $info;
    public $url;
    public $fotter;
    public $type;
    public $subMenu;
    public $is_open = true;
    public $padding = true;
    public $btn = [];

    public function init() {
        $url = \yii\helpers\Url::toRoute('/box/change/');
        $js = <<<JS
function colloapsedBox(_id) {
    setTimeout(function(){
        let clname = ".indic-" + _id;
        let sel = $(clname).hasClass('fa-minus')
        data  = {name:_id,isViewed:sel}
        $.get('$url',data)
    },200)
}    
JS;
        $this->getView()->registerJs($js, \yii\web\View::POS_BEGIN);
    }

    public function run() {

        $isViewed = $this->is_open;
        $session = \Yii::$app->session;
        $arr = $session->get(Box::sessName);
        if (isset($arr[$this->id])) {
            $isViewed = $arr[$this->id];
        } else {
            $isViewed = 'true';
        }

        return $this->render('index', [
                    'id' => $this->id ?? uniqid(),
                    'text' => $this->text,
                    'btn' => $this->btn,
                    'name' => $this->name,
                    'is_deleted' => $this->is_deleted,
                    'is_collapsed' => $this->is_collapsed,
                    'is_solid' => $this->is_solid,
                    'info' => $this->info,
                    'url' => $this->url,
                    'fotter' => $this->fotter,
                    'type' => $this->type,
                    'subMenu' => $this->subMenu,
                    'padding' => $this->padding,
                    'is_open' => $isViewed == 'true',
        ]);
    }

    public function saveState($name) {

        $customer = \common\models\CustomerSetting::find()->where(['user_id' => (int) \Yii::$app->user->id, 'name' => 'swtolbar'])->one(); // find by query
        if (!$customer) {
            $customer = new \common\models\CustomerSetting();
            $customer->user_id = \Yii::$app->user->id;
            $customer->name = 'swtolbar';
        }
        if ($customer->value == 'N') {
            $customer->value = 'Y';
        } else {
            $customer->value = 'N';
        }
        $customer->save();
    }

}
