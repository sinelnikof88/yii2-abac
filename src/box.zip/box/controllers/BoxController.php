<?php

/*
 * Gonnyh Ivan
 * sinelnikof88@gmail.com
 * Developing  by Yii
 * Each line should be prefixed with  * 
 */

namespace common\extensions\box\controllers;

/**
 * Description of BoxController
 *
 * @author Gonnyh.I
 */
use common\models\Constants;
use common\models\forms\BasketForm;
use common\models\forms\DocumentForm;
use Yii;
use yii\base\ErrorException;
use yii\db\StaleObjectException;
use yii\web\Controller;
use \common\extensions\box\Box;

class BoxController extends Controller {

    // изменеие и сохранение состояния бокса
    public function actionChange($name, $isViewed = false) {
        
        
        
        
        
        $session = Yii::$app->session;
        if (!$session->has(Box::sessName)) {
            $session->set(Box::sessName, []);
        }

        $arr = $session->get(Box::sessName);
        $arr[$name] = $isViewed;
        $session->set(Box::sessName, $arr);
        return;
    }

}
